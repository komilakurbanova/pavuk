import scrapy
from scrapy.http import HtmlResponse


class GameSpider(scrapy.Spider):
    name = 'game'
    allowed_domains = ['store.steampowered.com']
    start_urls = ['http://store.steampowered.com/']
    platforms = []

    def get_price(self, p: str):
        free = ['free', 'free to play', 'free movie']
        if p.lower() in free:
            return p.lower()
        symbs = '123456789'
        price = ''
        for ch in p:
            if ch == '$' or ch in symbs:
                price += ch
        return price

    def start_requests(self):
        for i in range(3):
            request = input()
            new_url = "https://store.steampowered.com/search/?term=" + request + "&force_infinite=1&&start=50&count=100"
            yield scrapy.Request(new_url, callback=self.parse)

    def parse(self, response: HtmlResponse, **kwargs):
        for href in response.xpath('//div[@id="search_resultsRows"]/a//@href').extract():
            if 'bundle' not in href:
                yield scrapy.Request(href, callback=self.game, cb_kwargs={'platform': [plt.split()[-1] for plt in response.xpath(f'//a[starts-with(@href, "{href}")]/div[@class="responsive_search_name_combined"]/div[@class="col search_name ellipsis"]/div/span//@class').extract()]})

    def game(self, response: HtmlResponse, **kwargs):
        if "agecheck" not in response.url:
            when_produced = response.xpath('//div[@class="date"]//text()').extract()
            when_produced_tmp = []
            if len(when_produced):
                when_produced_tmp = when_produced[0].split()
            status = ['Coming soon', 'TBA']
            if len(when_produced_tmp) > 0:
                if when_produced[0] in status or when_produced_tmp[-1] >= '2000':
                    items = {'name': response.xpath( "//div[contains(@class,'apphub_AppName') and contains(@id,'appHubAppName')]/text()").extract_first()}

                    categs = response.xpath('//div[@class="blockbg"]/a//text()').extract()
                    if len(categs) == 2:
                        categs.insert(1, "not categories")
                    items['category'] = " -> ".join([categs[i] for i in range(len(categs)) if i != 0 and i != len(categs) - 1])

                    stars = response.xpath(
                        "//div[contains(@class,'noReviewsYetTitle') or contains(@class,'game_review_summary positive') or contains(@class,'game_review_summary mixed') or contains(@class, 'game_review_summary not_enough_reviews')]/text()").extract()
                    if not len(stars):
                        stars = response.xpath(
                            "//span[contains(@class,'noReviewsYetTitle') or contains(@class,'game_review_summary positive') or contains(@class,'game_review_summary mixed') or contains(@class, 'game_review_summary not_enough_reviews')]/text()").extract()
                    if stars[0] == '\r\n\t\t\t\tThere are no reviews for this product\t\t\t' or stars[0] == '1 user reviews':
                        items['stars'] = 'Not enough reviews'
                    else:
                        items['stars'] = stars[0]

                    reviews = response.xpath(
                        '//*[@id="review_histogram_rollup_section"]/div[1]/div/span[2]/text()').extract_first()
                    if reviews == '' or reviews is None:
                        items['reviews'] = 'No reviews'
                    else:
                        items['reviews'] = reviews.split()[0][1::]

                    items['produce_date'] = when_produced[-1]

                    developers = response.xpath( '//div[contains(@class, "summary column") and contains(@id, "developers_list")]/a//text()').extract()
                    if not len(developers):
                        items['developers'] = 'No developers publicated'
                    else:
                        items['developers'] = '; '.join(developers)

                    items['tags'] = "; ".join([tag.strip() for tag in response.xpath(
                        "//div[@class='glance_tags popular_tags']/a//text()").extract()])

                    price = response.xpath( '//div[contains(@class,"game_purchase_price price") or contains(@class,"discount_original_price")]//text()').extract()
                    if not price:
                        items['price'] = 'No price'
                    else:
                        items['price'] = self.get_price(price[-1].strip())

                    items['platforms'] = "; ".join(response.cb_kwargs['platform'])

                    yield items
